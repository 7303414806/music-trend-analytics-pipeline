-- ═══════════════════════════════════════════════════════════════════════════════
-- schema.sql
-- Music Trend Intelligence — Snowflake Star Schema
-- ═══════════════════════════════════════════════════════════════════════════════

-- 1. Create Database and Schema
-- ─────────────────────────────────────────────────────────────────────────────
CREATE DATABASE IF NOT EXISTS MUSIC_ANALYTICS;
USE DATABASE MUSIC_ANALYTICS;
CREATE SCHEMA IF NOT EXISTS CORE;
USE SCHEMA CORE;


-- 2. Dimension Tables
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS dim_artists (
    artist_id       VARCHAR(50)  PRIMARY KEY,
    artist_name     VARCHAR(255) NOT NULL,
    genres          VARCHAR(500),
    followers       NUMBER,
    created_at      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE TABLE IF NOT EXISTS dim_albums (
    album_id        VARCHAR(50)  PRIMARY KEY,
    album_name      VARCHAR(255) NOT NULL,
    total_tracks    NUMBER,
    release_year    NUMBER(4),
    release_month   NUMBER(2),
    decade          VARCHAR(10),
    created_at      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE TABLE IF NOT EXISTS dim_dates (
    date_id         NUMBER       PRIMARY KEY AUTOINCREMENT,
    full_date       DATE,
    year            NUMBER(4),
    month           NUMBER(2),
    quarter         NUMBER(1),
    decade          VARCHAR(10),
    month_name      VARCHAR(20),
    created_at      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);


-- 3. Fact Table
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS fact_tracks (
    track_id          VARCHAR(50)   PRIMARY KEY,
    track_name        VARCHAR(255)  NOT NULL,
    artist_id         VARCHAR(50)   REFERENCES dim_artists(artist_id),
    album_id          VARCHAR(50)   REFERENCES dim_albums(album_id),

    -- Raw Spotify Audio Features
    popularity        NUMBER(3),
    duration_ms       NUMBER,
    duration_min      FLOAT,
    explicit          BOOLEAN,
    category          VARCHAR(100),
    playlist_name     VARCHAR(255),

    -- Engineered Features
    popularity_tier   VARCHAR(20),    -- Top 10% / Mid-tier / Long-tail

    -- Metadata
    extracted_at      TIMESTAMP_NTZ,
    loaded_at         TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);


-- 4. Snowpipe Setup — Auto-ingest from S3
-- ─────────────────────────────────────────────────────────────────────────────

-- Step 1: Create Storage Integration (run once with ACCOUNTADMIN role)
-- CREATE STORAGE INTEGRATION s3_music_integration
--   TYPE = EXTERNAL_STAGE
--   STORAGE_PROVIDER = 'S3'
--   ENABLED = TRUE
--   STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::YOUR_ACCOUNT_ID:role/snowflake-role'
--   STORAGE_ALLOWED_LOCATIONS = ('s3://YOUR_PROCESSED_BUCKET/processed/tracks/');

-- Step 2: Create External Stage
-- CREATE STAGE music_processed_stage
--   URL = 's3://YOUR_PROCESSED_BUCKET/processed/tracks/'
--   STORAGE_INTEGRATION = s3_music_integration
--   FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY = '"' SKIP_HEADER = 1);

-- Step 3: Create Snowpipe
-- CREATE PIPE music_tracks_pipe AUTO_INGEST = TRUE AS
--   COPY INTO fact_tracks (
--     track_id, track_name, artist_id, album_id,
--     popularity, duration_ms, duration_min, explicit,
--     category, playlist_name, popularity_tier, extracted_at
--   )
--   FROM @music_processed_stage
--   FILE_FORMAT = (TYPE = 'CSV' SKIP_HEADER = 1);

-- Note: After creating the pipe, get the SQS ARN:
-- SHOW PIPES;
-- Then configure S3 bucket notifications to send events to that SQS ARN.
