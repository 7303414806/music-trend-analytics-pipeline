-- ═══════════════════════════════════════════════════════════════════════════════
-- analytical_views.sql
-- Music Trend Intelligence — KPI Queries & Materialized Views
-- ═══════════════════════════════════════════════════════════════════════════════

USE DATABASE MUSIC_ANALYTICS;
USE SCHEMA CORE;


-- ── View 1: Top Artists by Average Popularity ─────────────────────────────────
CREATE OR REPLACE VIEW v_top_artists AS
SELECT
    a.artist_name,
    COUNT(f.track_id)           AS total_tracks,
    ROUND(AVG(f.popularity), 1) AS avg_popularity,
    MAX(f.popularity)           AS peak_popularity,
    LISTAGG(DISTINCT f.category, ', ')
        WITHIN GROUP (ORDER BY f.category) AS categories
FROM fact_tracks f
JOIN dim_artists a ON f.artist_id = a.artist_id
GROUP BY a.artist_name
ORDER BY avg_popularity DESC;


-- ── View 2: Genre Trend Analysis by Year ──────────────────────────────────────
CREATE OR REPLACE VIEW v_genre_trends AS
SELECT
    f.category                  AS genre,
    al.release_year,
    COUNT(f.track_id)           AS track_count,
    ROUND(AVG(f.popularity), 1) AS avg_popularity,
    ROUND(AVG(f.duration_min), 2) AS avg_duration_min
FROM fact_tracks f
JOIN dim_albums al ON f.album_id = al.album_id
WHERE al.release_year >= 2015
GROUP BY f.category, al.release_year
ORDER BY al.release_year DESC, avg_popularity DESC;


-- ── View 3: Popularity Tier Distribution ──────────────────────────────────────
CREATE OR REPLACE VIEW v_popularity_tiers AS
SELECT
    popularity_tier,
    COUNT(track_id)             AS track_count,
    ROUND(AVG(popularity), 1)   AS avg_popularity,
    ROUND(AVG(duration_min), 2) AS avg_duration_min,
    SUM(CASE WHEN explicit THEN 1 ELSE 0 END) AS explicit_count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_of_total
FROM fact_tracks
GROUP BY popularity_tier
ORDER BY avg_popularity DESC;


-- ── View 4: Decade-wise Music Evolution ───────────────────────────────────────
CREATE OR REPLACE VIEW v_decade_evolution AS
SELECT
    al.decade,
    COUNT(f.track_id)             AS total_tracks,
    ROUND(AVG(f.popularity), 1)   AS avg_popularity,
    ROUND(AVG(f.duration_min), 2) AS avg_duration_min,
    COUNT(DISTINCT f.artist_id)   AS unique_artists,
    COUNT(DISTINCT f.category)    AS genres_present
FROM fact_tracks f
JOIN dim_albums al ON f.album_id = al.album_id
WHERE al.decade IS NOT NULL
GROUP BY al.decade
ORDER BY al.decade;


-- ── View 5: Explicit vs Clean Track Performance ───────────────────────────────
CREATE OR REPLACE VIEW v_explicit_analysis AS
SELECT
    explicit,
    COUNT(track_id)             AS track_count,
    ROUND(AVG(popularity), 1)   AS avg_popularity,
    MAX(popularity)             AS max_popularity,
    ROUND(AVG(duration_min), 2) AS avg_duration_min
FROM fact_tracks
GROUP BY explicit;


-- ── View 6: Daily Load Summary (Pipeline Monitoring) ─────────────────────────
CREATE OR REPLACE VIEW v_daily_load_summary AS
SELECT
    DATE(loaded_at)             AS load_date,
    COUNT(track_id)             AS records_loaded,
    COUNT(DISTINCT artist_id)   AS unique_artists,
    COUNT(DISTINCT album_id)    AS unique_albums,
    COUNT(DISTINCT category)    AS genres_covered,
    MIN(loaded_at)              AS first_load_time,
    MAX(loaded_at)              AS last_load_time
FROM fact_tracks
GROUP BY DATE(loaded_at)
ORDER BY load_date DESC;


-- ── Ad-hoc KPI Queries ────────────────────────────────────────────────────────

-- Top 10 most popular tracks overall
SELECT track_name, artist_id, popularity, category, popularity_tier
FROM fact_tracks
ORDER BY popularity DESC
LIMIT 10;

-- Window function: Rank artists within each genre by popularity
SELECT
    category,
    artist_id,
    ROUND(AVG(popularity), 1) AS avg_pop,
    RANK() OVER (PARTITION BY category ORDER BY AVG(popularity) DESC) AS genre_rank
FROM fact_tracks
GROUP BY category, artist_id
QUALIFY genre_rank <= 3
ORDER BY category, genre_rank;

-- Month-over-month track count trend
SELECT
    TO_CHAR(DATE_TRUNC('month', loaded_at), 'YYYY-MM') AS month,
    COUNT(track_id) AS tracks_loaded,
    LAG(COUNT(track_id)) OVER (ORDER BY DATE_TRUNC('month', loaded_at)) AS prev_month,
    COUNT(track_id) - LAG(COUNT(track_id)) OVER (ORDER BY DATE_TRUNC('month', loaded_at)) AS mom_change
FROM fact_tracks
GROUP BY DATE_TRUNC('month', loaded_at)
ORDER BY month;
