"""
prompt_templates.py
────────────────────
Gen AI enrichment layer for the Music Trend Intelligence pipeline.

Uses Claude (Anthropic) or OpenAI API to:
  1. Generate natural-language trend summaries from track cluster data
  2. Auto-tag tracks with semantic mood labels
  3. Suggest playlist names based on audio feature profiles

Usage:
  python prompt_templates.py
  (Requires ANTHROPIC_API_KEY or OPENAI_API_KEY in your .env)
"""

import os
import json
import anthropic   # pip install anthropic
# import openai    # Alternative: pip install openai

# ─────────────────────────────────────────────────────────────────────────────
# PROMPT TEMPLATES
# ─────────────────────────────────────────────────────────────────────────────

TREND_SUMMARY_PROMPT = """
You are a music data analyst. Based on the following aggregated track statistics
for a music genre, write a concise 2-3 sentence trend summary suitable for
an executive dashboard. Be specific, data-driven, and avoid generic statements.

Genre Data:
{genre_data}

Respond with only the summary paragraph. No bullet points. No headers.
"""

MOOD_TAG_PROMPT = """
You are a music metadata specialist. Based on the following audio feature profile
of a track, assign ONE mood tag from this list:
[high-energy workout, melancholic indie, relaxed acoustic, party anthem,
 focus/study, romantic, dark alternative, feel-good pop, aggressive rap,
 cinematic/ambient]

Track Profile:
- Popularity: {popularity}/100
- Duration: {duration_min} minutes
- Explicit: {explicit}
- Genre category: {category}

Respond with ONLY the mood tag. Nothing else.
"""

PLAYLIST_NAME_PROMPT = """
You are a creative music curator. Based on the following cluster of tracks
and their shared audio characteristics, suggest ONE creative playlist name
(4-6 words maximum) that captures the mood and energy.

Cluster summary:
{cluster_summary}

Respond with ONLY the playlist name. No quotes. No explanation.
"""


# ─────────────────────────────────────────────────────────────────────────────
# API CALL FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def get_trend_summary(genre_data: dict) -> str:
    """
    Calls Claude API to generate a trend summary for a genre.

    Args:
        genre_data: dict with keys like avg_popularity, track_count, avg_duration_min, decade
    Returns:
        str: 2-3 sentence trend narrative
    """
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    prompt = TREND_SUMMARY_PROMPT.format(genre_data=json.dumps(genre_data, indent=2))

    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=200,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text.strip()


def get_mood_tag(track: dict) -> str:
    """
    Calls Claude API to assign a semantic mood tag to a single track.

    Args:
        track: dict with popularity, duration_min, explicit, category
    Returns:
        str: mood tag label
    """
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    prompt = MOOD_TAG_PROMPT.format(
        popularity=track.get("popularity", 50),
        duration_min=track.get("duration_min", 3.5),
        explicit=track.get("explicit", False),
        category=track.get("category", "unknown")
    )

    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=20,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text.strip()


def get_playlist_name(cluster_summary: dict) -> str:
    """
    Calls Claude API to generate a creative playlist name for a track cluster.

    Args:
        cluster_summary: dict describing the cluster's shared characteristics
    Returns:
        str: creative playlist name
    """
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    prompt = PLAYLIST_NAME_PROMPT.format(
        cluster_summary=json.dumps(cluster_summary, indent=2)
    )

    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=30,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text.strip()


# ─────────────────────────────────────────────────────────────────────────────
# DEMO — Run standalone
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":

    # Example 1: Trend Summary
    sample_genre = {
        "genre": "latin",
        "avg_popularity": 72.4,
        "track_count": 312,
        "avg_duration_min": 3.42,
        "top_decade": "2020s",
        "yoy_popularity_change": "+8.3%"
    }
    print("=== TREND SUMMARY ===")
    print(get_trend_summary(sample_genre))
    print()

    # Example 2: Mood Tag
    sample_track = {
        "popularity": 85,
        "duration_min": 3.1,
        "explicit": True,
        "category": "hiphop"
    }
    print("=== MOOD TAG ===")
    print(get_mood_tag(sample_track))
    print()

    # Example 3: Playlist Name
    sample_cluster = {
        "dominant_mood": "energetic",
        "avg_popularity": 78,
        "genres": ["edm_dance", "pop"],
        "decade": "2020s",
        "avg_duration_min": 3.0
    }
    print("=== PLAYLIST NAME ===")
    print(get_playlist_name(sample_cluster))
