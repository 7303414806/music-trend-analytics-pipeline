"""
transformer.py
──────────────
AWS Lambda function — Stage 2 of the ETL pipeline.

Responsibilities:
  - Triggered automatically when a new JSON file lands in the S3 raw bucket
  - Reads raw JSON, flattens nested fields, cleans and casts data types
  - Removes duplicate track records
  - Uploads transformed CSV to the S3 processed bucket
  - Processed CSV is then picked up by Snowpipe for Snowflake ingestion

Environment Variables Required:
  S3_PROCESSED_BUCKET : Name of your processed/transformed S3 bucket
"""

import os
import json
import boto3
import pandas as pd
from io import StringIO
from datetime import datetime


# ── Read raw JSON from S3 ─────────────────────────────────────────────────────
def read_raw_from_s3(bucket, key):
    s3 = boto3.client("s3")
    obj = s3.get_object(Bucket=bucket, Key=key)
    raw_data = json.loads(obj["Body"].read().decode("utf-8"))
    print(f"[INFO] Read {len(raw_data)} records from s3://{bucket}/{key}")
    return raw_data


# ── Transform ─────────────────────────────────────────────────────────────────
def transform(raw_records):
    """
    Cleans and enriches raw track records.

    Steps:
      1. Load into DataFrame
      2. Drop duplicates on track_id
      3. Cast and normalise data types
      4. Parse release_date → year, month, decade
      5. Drop rows with critical nulls
      6. Add load timestamp
    """
    df = pd.DataFrame(raw_records)

    # 1. Deduplicate
    before = len(df)
    df = df.drop_duplicates(subset=["track_id"])
    print(f"[INFO] Removed {before - len(df)} duplicate tracks.")

    # 2. Drop critical nulls
    df = df.dropna(subset=["track_id", "artist_id", "album_id"])

    # 3. Type casting
    df["popularity"]   = pd.to_numeric(df["popularity"], errors="coerce").fillna(0).astype(int)
    df["duration_ms"]  = pd.to_numeric(df["duration_ms"], errors="coerce").fillna(0).astype(int)
    df["explicit"]     = df["explicit"].astype(bool)
    df["track_name"]   = df["track_name"].str.strip().str[:255]
    df["artist_name"]  = df["artist_name"].str.strip().str[:255]
    df["album_name"]   = df["album_name"].str.strip().str[:255]

    # 4. Parse release date → year / month / decade
    df["release_date"] = pd.to_datetime(df["release_date"], errors="coerce")
    df["release_year"]  = df["release_date"].dt.year.fillna(0).astype(int)
    df["release_month"] = df["release_date"].dt.month.fillna(0).astype(int)
    df["decade"]        = (df["release_year"] // 10 * 10).astype(str) + "s"

    # 5. Popularity tier classification (Feature Engineering)
    p90 = df["popularity"].quantile(0.90)
    p50 = df["popularity"].quantile(0.50)
    df["popularity_tier"] = df["popularity"].apply(
        lambda x: "Top 10%" if x >= p90 else ("Mid-tier" if x >= p50 else "Long-tail")
    )

    # 6. Duration in minutes
    df["duration_min"] = (df["duration_ms"] / 60000).round(2)

    # 7. Load timestamp
    df["loaded_at"] = datetime.utcnow().isoformat()

    # Drop raw release_date column (keep year/month/decade)
    df = df.drop(columns=["release_date"], errors="ignore")

    print(f"[INFO] Transformed {len(df)} clean records.")
    return df


# ── Upload CSV to S3 processed bucket ─────────────────────────────────────────
def upload_csv_to_s3(df, bucket):
    s3 = boto3.client("s3")
    timestamp = datetime.utcnow().strftime("%Y/%m/%d/%H%M%S")
    key = f"processed/tracks/{timestamp}_tracks_clean.csv"

    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)

    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=csv_buffer.getvalue(),
        ContentType="text/csv"
    )
    print(f"[INFO] Uploaded {len(df)} rows to s3://{bucket}/{key}")
    return key


# ── Lambda Handler ─────────────────────────────────────────────────────────────
def lambda_handler(event, context):
    # S3 event trigger — get source bucket + key
    record   = event["Records"][0]["s3"]
    bucket   = record["bucket"]["name"]
    key      = record["object"]["key"]

    raw_data = read_raw_from_s3(bucket, key)
    df_clean = transform(raw_data)

    processed_bucket = os.environ["S3_PROCESSED_BUCKET"]
    s3_key = upload_csv_to_s3(df_clean, processed_bucket)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Transformation complete",
            "clean_records": len(df_clean),
            "output_key": s3_key
        })
    }
