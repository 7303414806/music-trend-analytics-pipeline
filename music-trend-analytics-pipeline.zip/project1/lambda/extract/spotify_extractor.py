"""
spotify_extractor.py
────────────────────
AWS Lambda function — Stage 1 of the ETL pipeline.

Responsibilities:
  - Authenticate with the Spotify API using Spotipy
  - Extract track, artist, and album metadata for configured playlists/categories
  - Upload raw JSON responses to the S3 raw bucket
  - Trigger is set via AWS CloudWatch (daily schedule)

Environment Variables Required (set in Lambda → Configuration → Environment):
  SPOTIFY_CLIENT_ID       : Your Spotify Developer app client ID
  SPOTIFY_CLIENT_SECRET   : Your Spotify Developer app client secret
  S3_RAW_BUCKET           : Name of your raw S3 bucket
  AWS_REGION              : e.g. us-east-1
"""

import os
import json
import boto3
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from datetime import datetime


# ── Spotify Auth ───────────────────────────────────────────────────────────────
def get_spotify_client():
    auth_manager = SpotifyClientCredentials(
        client_id=os.environ["SPOTIFY_CLIENT_ID"],
        client_secret=os.environ["SPOTIFY_CLIENT_SECRET"]
    )
    return spotipy.Spotify(auth_manager=auth_manager)


# ── Extract Top Tracks per Category ───────────────────────────────────────────
def extract_tracks(sp, category_ids=None):
    """
    Extracts track metadata from Spotify's featured playlists.
    Returns a list of raw track dictionaries.
    """
    if category_ids is None:
        category_ids = ["pop", "hiphop", "latin", "rock", "edm_dance", "rnb", "indie_alt"]

    all_tracks = []

    for category in category_ids:
        try:
            # Get playlists for this category
            playlists = sp.category_playlists(category_id=category, limit=3)
            for playlist in playlists["playlists"]["items"]:
                playlist_id = playlist["id"]
                playlist_name = playlist["name"]

                # Get tracks from playlist
                results = sp.playlist_tracks(playlist_id, limit=50)
                for item in results["items"]:
                    track = item.get("track")
                    if track is None:
                        continue

                    track_data = {
                        "track_id":       track["id"],
                        "track_name":     track["name"],
                        "artist_id":      track["artists"][0]["id"] if track["artists"] else None,
                        "artist_name":    track["artists"][0]["name"] if track["artists"] else None,
                        "album_id":       track["album"]["id"],
                        "album_name":     track["album"]["name"],
                        "release_date":   track["album"]["release_date"],
                        "popularity":     track["popularity"],
                        "duration_ms":    track["duration_ms"],
                        "explicit":       track["explicit"],
                        "category":       category,
                        "playlist_name":  playlist_name,
                        "extracted_at":   datetime.utcnow().isoformat()
                    }
                    all_tracks.append(track_data)

        except Exception as e:
            print(f"[WARN] Failed for category '{category}': {e}")
            continue

    print(f"[INFO] Extracted {len(all_tracks)} tracks total.")
    return all_tracks


# ── Upload to S3 ───────────────────────────────────────────────────────────────
def upload_to_s3(data, bucket_name):
    s3 = boto3.client("s3")
    timestamp = datetime.utcnow().strftime("%Y/%m/%d/%H%M%S")
    key = f"raw/tracks/{timestamp}_tracks.json"

    s3.put_object(
        Bucket=bucket_name,
        Key=key,
        Body=json.dumps(data, indent=2),
        ContentType="application/json"
    )
    print(f"[INFO] Uploaded {len(data)} records to s3://{bucket_name}/{key}")
    return key


# ── Lambda Handler ─────────────────────────────────────────────────────────────
def lambda_handler(event, context):
    sp = get_spotify_client()
    tracks = extract_tracks(sp)

    bucket = os.environ["S3_RAW_BUCKET"]
    s3_key = upload_to_s3(tracks, bucket)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Extraction complete",
            "records": len(tracks),
            "s3_key": s3_key
        })
    }


# ── Local test (runs without Lambda) ──────────────────────────────────────────
if __name__ == "__main__":
    # For local testing — set env vars or hardcode temporarily (never commit keys)
    result = lambda_handler({}, {})
    print(result)
